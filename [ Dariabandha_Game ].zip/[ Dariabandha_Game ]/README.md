# Dariabandha: The Guarded Court

A real-time, 2-player browser adaptation of **Dariabandha** (দাড়িয়াবান্ধা), a
traditional rural field game of Bangladesh — built with plain HTML, CSS, and
vanilla JavaScript, with a CSS-only pseudo-3D board. No frameworks, no build
step, no server-side code required. Open `index.html`, or deploy it as a
static site, and play.

---

## Contents

- [Introduction](#introduction)
- [History & Cultural Importance](#history--cultural-importance)
- [Objectives](#objectives)
- [Gameplay](#gameplay)
- [Rules](#rules)
- [Controls](#controls)
- [Installation](#installation)
- [Folder Structure](#folder-structure)
- [Features](#features)
- [Languages](#languages)
- [Photo Upload Guide](#photo-upload-guide)
- [Customization Guide](#customization-guide)
- [Project Architecture](#project-architecture)
- [Technologies Used](#technologies-used)
- [A Note on Audio](#a-note-on-audio)
- [Deployment](#deployment)
- [Browser Compatibility](#browser-compatibility)
- [Performance Notes](#performance-notes)
- [Known Limitations](#known-limitations)
- [Future Improvements](#future-improvements)
- [License](#license)
- [Credits & Submission Information](#credits--submission-information)

---

## Introduction

Two players share one keyboard. One runs; one guards. The Runner must cross
a line of patrolling guards, touch the far end of the court, and make it
all the way back — without being tagged — to score. Miss, and the guards
score instead, and the two players swap roles. First to the target score
wins the match.

## History & Cultural Importance

Dariabandha ("Daria" = a boat-rower; "Bandha" = barrier/obstacle) was a
staple of the dry season across rural Bangladesh, played on harvested
fields once the ground was firm enough to mark court lines into the earth
with a spade. It's enjoyed by children and adults, boys and girls, in
almost every region — though, like many folk games, it's fading as open
fields disappear. Full research notes and sources are in
[`docs/RESEARCH.md`](docs/RESEARCH.md).

## Objectives

1. Represent the real guard-line / circuit-completion mechanic faithfully.
2. Be genuinely replayable, not a one-time demo.
3. Run cleanly in any modern browser and deploy with zero build step.
4. Support 5 languages, including full right-to-left Arabic.
5. Match the polish of a commercial small-team browser game.

## Gameplay

Each **round** has exactly one **Runner** and one **Daria Guard** (both
human-controlled), plus 5 AI-controlled **Line Guards**. The Runner tries
to run the length of the court and back without being touched. The round
ends the instant the Runner is tagged, or the instant they complete the
full there-and-back circuit. Roles swap every round. First player to reach
the match's target score (3 / 5 / 7, chosen at setup) wins.

## Rules

- **Line Guards** each patrol exactly one guard-line, moving only
  left–right, at a speed set by the chosen difficulty.
- **Daria Guard** (human #2) can roam the entire central lane, up and down
  — mirroring the front defender's traditional privilege to use the full
  vertical court.
- **Safe zones**: the start and finish baselines are untaggable strips.
- **Tagging**: any guard's hitbox touching the Runner outside a safe zone
  ends the round for the Guards.
- **Scoring a circuit**: reaching the far baseline alone doesn't score —
  only completing the full return trip does.
- See the in-game **How To Play** panel (Main Menu → How To Play) for the
  same rules with live diagrams, and the interactive tutorial shown the
  first time you start a match.

## Controls

| Role | Move | Alt (touch) |
|---|---|---|
| Runner | Arrow keys **or** `8` `2` `4` `6` (up/down/left/right) | On-screen D-pad (left) |
| Daria Guard | `W` `A` `S` `D` | On-screen D-pad (right) |
| Ready / start round | `Space` | — |
| Pause / resume | `Esc` or pause button | pause button |

The `8`/`2`/`4`/`6` number keys are a built-in fallback for keyboards where the
arrow keys double as a numeric keypad — if NumLock sends plain digits instead
of `Arrow*` on your keyboard, the Runner still moves correctly using those
number keys, laid out like a phone dial pad (`8`=up, `2`=down, `4`=left,
`6`=right). This is shown as a small hint on the Player Setup screen too.

Touch D-pads appear automatically on touch/coarse-pointer devices.

## Installation

No build tools, no dependencies to install.

1. Download/extract the ZIP (or clone the repo).
2. Double-click `index.html` to play locally, **or**
3. Deploy the folder as-is to any static host (see
   [Deployment](#deployment)).

## Folder Structure

```
dariabandha/
├── index.html              entry point — open this
├── README.md
├── LICENSE
├── css/
│   ├── variables.css        design tokens (colors, type, radii, shadows)
│   ├── base.css              reset + base typography
│   ├── layout.css            screens, main menu, setup screen
│   ├── board.css              the pseudo-3D court
│   ├── characters.css        runner/guard tokens + their animations
│   ├── ui.css                 buttons, HUD, modals, touch pads
│   ├── animations.css        shared keyframes + reduced-motion handling
│   └── responsive.css        breakpoints
├── js/
│   ├── i18n.js                translation engine (reads /lang)
│   ├── state.js               match/round state store
│   ├── board.js                court geometry + DOM building
│   ├── entities.js            runner/guard movement + collision
│   ├── input.js                keyboard + touch input
│   ├── ui.js                    screens, modals, HUD, setup form
│   └── main.js                boot + round-loop orchestration
├── lang/
│   ├── en.js  bn.js  ko.js  ar.js  es.js
├── assets/
│   ├── images/                default avatars + emblem (original SVG art)
│   └── icons/                  see NOTE.md — icon sprite is inlined in index.html
└── docs/
    ├── RESEARCH.md            grounded research summary + sources
    ├── 5W1H.md
    └── PRD.md                 full product requirements document
```

## Features

- Pseudo-3D tilted court built with CSS `perspective`/`rotateX`/`translateZ`
  — no canvas, no WebGL, no Three.js.
- Real-time movement and collision, not turn-based dice.
- 5 AI line guards with difficulty-scaled patrol speed and a light "seek"
  behavior on Hard.
- Photo upload for both players with circular preview, and original
  hand-drawn default avatars if you skip it.
- Nickname setup, match-length picker (3/5/7), difficulty picker.
- Full interactive tutorial (first run) + a static How To Play reference.
- Pause/resume, restart, rematch, fullscreen, reduce-motion toggle.
- 5-language localization with persistent choice + browser-language
  auto-detect, full RTL for Arabic.
- `prefers-reduced-motion` support (automatic + manual toggle); keyboard-
  first design; readable high-contrast HUD.
- Fully responsive: desktop, tablet, and mobile, portrait and landscape.

## Languages

English, Bangla (বাংলা), Korean (한국어), Arabic (العربية — RTL), Spanish
(Español). Every button, modal, tutorial step, rule explanation, and
toast notification is translated — see `/lang/*.js`.

## Photo Upload Guide

On the Player Setup screen, tap either player's circular avatar to choose
an image from your device. It's previewed immediately and used for that
player's token on the board and in the HUD for the rest of the session.
Nothing is uploaded anywhere — it's read locally into the page with the
`FileReader` API and kept only in memory for that session.

## Customization Guide

- **Palette / look**: all colors are CSS custom properties in
  `css/variables.css` — change them once, everything updates.
- **Court difficulty numbers**: guard speeds and the Hard-mode seek
  strength are constants at the top of `js/entities.js`
  (`DIFFICULTY_SPEED`, `DIFFICULTY_SEEK`).
- **Adding a language**: copy `lang/en.js` to `lang/xx.js`, translate every
  value, add `'xx'` to `SUPPORTED` in `js/i18n.js`, add it to `LANG_NAMES`
  in `js/ui.js`, and add a `<script src="lang/xx.js">` tag in `index.html`
  before `js/i18n.js`.
- **Default avatars / emblem**: swap the SVGs in `assets/images/` for your
  own artwork; nothing else needs to change.

## Project Architecture

Every module attaches itself to a single global namespace, `window.DB`
(`DB.state`, `DB.board`, `DB.entities`, `DB.input`, `DB.i18n`, `DB.ui`),
and files are loaded as plain classic `<script>` tags in a fixed order in
`index.html` — deliberately **not** ES modules, so the project behaves
identically whether it's opened directly from disk or served from a real
host. `main.js` is the only file that reaches into more than one other
module to orchestrate the round loop — every other file has a single,
clear responsibility.

## Technologies Used

HTML5, CSS3 (custom properties, `perspective`/3D transforms, Grid,
Flexbox), vanilla JavaScript (ES6+, functional-closure modules),
`localStorage`, `FileReader`, Google Fonts (via CDN). No frameworks, no
build tooling.

## A Note on Audio

This build intentionally ships with **no sound** — no sound effects, no
background music, no `/audio` folder, and no audio-related code — per the
finalized project brief. All feedback is delivered visually instead:
button hover/press states, glow highlights on selectable pieces, screen
shake-free but clearly readable tag flashes, toast notifications, and
eased transitions throughout (`css/ui.css`, `css/animations.css`,
`css/characters.css`).

## Deployment

This is a static site — any static host works with zero configuration:

- **GitHub Pages**: push the folder to a repo, enable Pages on the branch
  (or `/docs` if you place the game there), done.
- **Netlify / Vercel**: drag-and-drop the folder (or connect the repo) with
  no build command and `.` (or the project root) as the publish directory.
- **Local**: double-click `index.html`, or serve it with any static server
  (`python3 -m http.server`, VS Code Live Server, etc.) — both work
  identically since the app uses classic scripts, not ES modules.

The only external network dependency is the Google Fonts CDN link in
`index.html`'s `<head>`; if it's unreachable, the UI falls back to system
fonts automatically and the game is otherwise unaffected.

## Browser Compatibility

Any modern evergreen browser: Chrome, Edge, Firefox, Safari, from roughly
the last 3–4 years. Requires CSS `perspective`/3D transforms (broadly
supported). Internet Explorer is not supported.

## Performance Notes

The round loop uses a single `requestAnimationFrame` tick with delta-time
movement (not per-frame fixed steps), so speed stays consistent across
refresh rates. DOM writes are batched to one `left`/`top` update per
entity per frame; there is no per-frame layout thrashing (no reads
interleaved with writes inside the loop). `prefers-reduced-motion` (or the
manual Settings toggle) shortens every CSS animation/transition project-
wide.

## Known Limitations

- This is a 1-Runner-vs-1-Daria-Guard duel adaptation of a traditionally
  4–6-a-side team game — see `docs/RESEARCH.md` for why, and what was
  preserved from the original mechanic.
- No online multiplayer; it's local hotseat by design (one keyboard, two
  players), matching how the physical game is actually played together.
- No persistent leaderboard/save-across-sessions beyond language,
  reduced-motion preference, and "have I seen the tutorial" — match scores
  reset each session by design, matching a real pickup match.

## Future Improvements

- A second AI-controlled opponent mode for solo practice.
- Configurable guard-line count (currently fixed at 5).
- Additional languages beyond the initial 5.
- Optional light sound design as a togglable extra, if a future revision
  of the brief calls for it.

## Submitted By
` Bangladesh Traditional Game `
`[ Dariabandha_[Team_2]_[U173_U171_U111 ] [ Batch 1 ] `

` Team Leader: `
` • U173 – Tonny Talukder `
`   ID: 0432220005101050 `
`   Email: 0432220005101050@uits.edu.bd `
`   Phone Number : +88 01720219644 `

` Team Members: `
` • U171 – Taposhi Rabia Fardin `
`   ID: 0432220005101049 `
`   Email: 0432220005101049@uits.edu.bd `

` • U111 – Fahim Sahariar Alvi `
`   ID: 0432220005101026 `
`   Email: 0432220005101026@uits.edu.bd ]`

