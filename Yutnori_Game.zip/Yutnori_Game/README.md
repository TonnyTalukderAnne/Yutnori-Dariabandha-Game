# 윷놀이 · Yutnori — 3D Web Game

A browser-based, two-player (hotseat) traditional Korean Yutnori game with a
tilted 3D wooden board, animated yut-stick throws, and full support for five
languages (Korean, English, Bengali, Arabic, Spanish).

## How to play it

No install needed — it's a static site.

- **Easiest:** double-click `index.html` to open it directly in a browser.
- **If your browser blocks local file access for images/fonts:** run a tiny
  local server from this folder and open the printed URL, e.g.
  `python3 -m http.server 8000` → visit `http://localhost:8000`.

## Personalizing the pieces with your own photo

The two piece tokens are loaded from:

- `pieces/player1.png`
- `pieces/player2.png`

Right now these are placeholder "P1"/"P2" discs. Replace those two files with
square-ish photos of the two players (any image size/aspect works — it's
clipped into a circle automatically) and reload the page. No code changes
needed; the filenames must stay the same.

## What's implemented

- Do/Gae/Geol/Yut/Mo throw results, correct move distances, bonus throws on
  Yut/Mo and on capturing an opponent's piece.
- Hidden Back-Do rule (one marked stick flips the "Do" result into a 1-space
  retreat).
- Catching, stacking (같은 편 말 업기), the 4 diagonal shortcuts + center
  junction with the "only choose a path when starting a move from a spot
  you were already resting on" rule, and full-lap win detection.
- Turn switching, whose-turn-is-it indicator, restart, waiting/finished piece
  counts per player, 2 or 4 piece game length.
- A move-history log, animated yut-stick toss (real 3D CSS flip), and
  step-by-step piece movement animation.
- Language switcher (top-right, persists via `localStorage`, auto-detects
  browser language on first visit) covering every on-screen string,
  including right-to-left layout for Arabic.

## Files

```
index.html   — screens & markup
style.css    — obangsaek/hanji/wood palette, the 3D board & stick flip
i18n.js       — ko / en / bn / ar / es translation dictionaries
game.js       — board graph, rules, animation, rendering
pieces/       — player token images (replace with your own photos)
```

## Submited By

`Tonny Talukder`