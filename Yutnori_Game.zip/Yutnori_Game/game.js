'use strict';
/* =========================================================================
   Yutnori — game.js
   Board: 29 nodes (20 outer + 8 diagonal shortcut + 1 center), stored as
   fractional (0..1) coordinates so the board scales responsively while the
   .board-plate/.board-3d ancestors apply the real CSS 3D perspective tilt.
   ========================================================================= */

/* ---------------------------------------------------------
 * 1. Board graph
 * --------------------------------------------------------- */
const NODES = {};
const lerp = (a, b, tt) => a + (b - a) * tt;

NODES.o0 = { x: 0.88, y: 0.88, type: 'start' };
NODES.o5 = { x: 0.88, y: 0.12, type: 'corner' };
NODES.o10 = { x: 0.12, y: 0.12, type: 'corner' };
NODES.o15 = { x: 0.12, y: 0.88, type: 'corner' };

function fillEdge(fromId, toId, ids) {
  const a = NODES[fromId], b = NODES[toId];
  ids.forEach((id, i) => {
    const tt = (i + 1) / (ids.length + 1);
    NODES[id] = { x: lerp(a.x, b.x, tt), y: lerp(a.y, b.y, tt), type: 'outer' };
  });
}
fillEdge('o0', 'o5', ['o1', 'o2', 'o3', 'o4']);
fillEdge('o5', 'o10', ['o6', 'o7', 'o8', 'o9']);
fillEdge('o10', 'o15', ['o11', 'o12', 'o13', 'o14']);
fillEdge('o15', 'o0', ['o16', 'o17', 'o18', 'o19']);

NODES.c = { x: 0.5, y: 0.5, type: 'center' };

function fillDiag(fromId, ids) {
  const a = NODES[fromId], b = NODES.c;
  ids.forEach((id, i) => {
    const tt = (i + 1) / (ids.length + 1);
    NODES[id] = { x: lerp(a.x, b.x, tt), y: lerp(a.y, b.y, tt), type: 'diag' };
  });
}
fillDiag('o0', ['a1', 'a2']);
fillDiag('o10', ['a4', 'a3']);
fillDiag('o5', ['b1', 'b2']);
fillDiag('o15', ['b4', 'b3']);

const OUTER_NEXT = {
  o0: 'o1', o1: 'o2', o2: 'o3', o3: 'o4', o4: 'o5',
  o5: 'o6', o6: 'o7', o7: 'o8', o8: 'o9', o9: 'o10',
  o10: 'o11', o11: 'o12', o12: 'o13', o13: 'o14', o14: 'o15',
  o15: 'o16', o16: 'o17', o17: 'o18', o18: 'o19', o19: 'FINISH',
};
const DIAG_NEAR = { o5: 'b1', o10: 'a4', o15: 'b4' };
const DIAG_ADJ = {
  a1: ['o0', 'a2'], a2: ['a1', 'c'], a3: ['c', 'a4'], a4: ['a3', 'o10'],
  b1: ['o5', 'b2'], b2: ['b1', 'c'], b3: ['c', 'b4'], b4: ['b3', 'o15'],
};
const CORNER_SET = new Set(['o5', 'o10', 'o15']);
const CENTER_NEIGHBORS = ['a2', 'a3', 'b2', 'b3'];
const STRAIGHT_PAIR = { a2: 'a3', a3: 'a2', b2: 'b3', b3: 'b2' };

const CORNER_NAME_KEY = { o5: 'pos.cornerTR', o10: 'pos.cornerTL', o15: 'pos.cornerBL' };
const CENTER_OPTION_KEY = { a2: 'centerOpt.toStart', a3: 'centerOpt.toTL', b2: 'centerOpt.toTR', b3: 'centerOpt.toBL' };

function isJunctionNode(id) { return id === 'c' || CORNER_SET.has(id); }

function nextOptions(current, from) {
  if (current === 'c') return CENTER_NEIGHBORS.filter((n) => n !== from);
  if (DIAG_ADJ[current]) {
    const [n1, n2] = DIAG_ADJ[current];
    const nxt = n1 === from ? n2 : n1;
    return nxt === 'o0' ? ['FINISH'] : [nxt];
  }
  if (CORNER_SET.has(current)) {
    const outer = OUTER_NEXT[current];
    const diag = DIAG_NEAR[current];
    return from === diag ? [outer] : [outer, diag];
  }
  return [OUTER_NEXT[current]];
}

function forcedContinue(current, from) {
  if (current === 'c') return [STRAIGHT_PAIR[from]];
  if (CORNER_SET.has(current)) return [OUTER_NEXT[current]];
  return nextOptions(current, from);
}

function optionLabel(nodeId) {
  return CENTER_OPTION_KEY[nodeId] ? t(CENTER_OPTION_KEY[nodeId]) : null;
}

function describePos(pos) {
  if (pos === 'c') return t('pos.center');
  if (CORNER_NAME_KEY[pos]) return t(CORNER_NAME_KEY[pos]);
  if (pos === 'o0') return t('pos.start');
  return pos;
}

/* ---------------------------------------------------------
 * 2. Game state
 * --------------------------------------------------------- */
let players = [];
let currentPlayerIdx = 0;
let pieceTotal = 4;
let gameOver = false;
let busy = false;
let lastResult = null;
let lastWinnerName = null;

const PLAYER_IMAGE = ['pieces/player1.png', 'pieces/player2.png'];

function makePlayer(name) {
  return { name, waiting: pieceTotal, finished: 0, groups: [] };
}

/* ---------------------------------------------------------
 * 3. DOM references
 * --------------------------------------------------------- */
const el = {
  setupScreen: document.getElementById('setup-screen'),
  gameScreen: document.getElementById('game-screen'),
  winScreen: document.getElementById('win-screen'),
  pieceCountGroup: document.getElementById('piece-count-group'),
  p1NameInput: document.getElementById('p1-name'),
  p2NameInput: document.getElementById('p2-name'),
  startBtn: document.getElementById('start-btn'),
  board: document.getElementById('board'),
  choicePanel: document.getElementById('choice-panel'),
  turnIndicator: document.getElementById('turn-indicator'),
  sticks: document.getElementById('sticks'),
  resultBanner: document.getElementById('result-banner'),
  resultAnimalUse: document.getElementById('result-animal-use'),
  resultLabel: document.getElementById('result-label'),
  resultSteps: document.getElementById('result-steps'),
  resultBonus: document.getElementById('result-bonus'),
  rollBtn: document.getElementById('roll-btn'),
  restartBtn: document.getElementById('restart-btn'),
  hintBar: document.getElementById('hint-bar'),
  playerCards: [document.getElementById('player-card-0'), document.getElementById('player-card-1')],
  logList: document.getElementById('log-list'),
  winMessage: document.getElementById('win-message'),
  playAgainBtn: document.getElementById('play-again-btn'),
  langBtn: document.getElementById('lang-btn'),
  langBtnLabel: document.getElementById('lang-btn-label'),
  langMenu: document.getElementById('lang-menu'),
  rulesToggleBtn: document.getElementById('rules-toggle-btn'),
  rulesPanel: document.getElementById('rules-panel'),
};

/* ---------------------------------------------------------
 * 4. Board rendering (div-based, so real CSS 3D transforms apply)
 * --------------------------------------------------------- */
function pct(v) { return `${(v * 100).toFixed(3)}%`; }

function buildBoardDom() {
  el.board.innerHTML = '';

  const outerLoop = [['o0', 'o5'], ['o5', 'o10'], ['o10', 'o15'], ['o15', 'o0']];
  outerLoop.forEach(([a, b]) => el.board.appendChild(makeLine(NODES[a], NODES[b], false)));
  [['o0', 'o10'], ['o5', 'o15']].forEach(([a, b]) => el.board.appendChild(makeLine(NODES[a], NODES[b], true)));

  Object.keys(NODES).forEach((id) => {
    const n = NODES[id];
    const node = document.createElement('div');
    node.className = 'node ' + (n.type === 'start' ? 'start' : (n.type === 'corner' || n.type === 'center') ? 'junction' : '');
    node.id = `node-${id}`;
    node.style.left = pct(n.x);
    node.style.top = pct(n.y);
    el.board.appendChild(node);

    if (n.type === 'start') {
      const label = document.createElement('div');
      label.className = 'node-label';
      label.textContent = t('board.startLabel');
      label.style.left = pct(n.x);
      label.style.top = pct(n.y);
      label.id = 'start-node-label';
      el.board.appendChild(label);
    }
  });

  const piecesLayer = document.createElement('div');
  piecesLayer.id = 'pieces-layer';
  el.board.appendChild(piecesLayer);
}

function makeLine(a, b, isDiag) {
  const dx = b.x - a.x, dy = b.y - a.y;
  const angle = Math.atan2(dy, dx) * (180 / Math.PI);
  const len = Math.sqrt(dx * dx + dy * dy);
  const line = document.createElement('div');
  line.className = 'board-line' + (isDiag ? ' diag' : '');
  line.style.left = pct(a.x);
  line.style.top = pct(a.y);
  line.style.width = pct(len);
  line.style.transform = `rotate(${angle}deg)`;
  return line;
}

/* Piece tokens: a photo/placeholder disc + a fake "side" wall for depth. Same
   token markup is reused for static pieces, the moving ghost, and selection
   highlighting, so every state looks identical (per the brief's 4.3-style rule). */
function buildPieceToken(pIdx, count) {
  const wrap = document.createElement('div');
  wrap.className = `piece-token p${pIdx}`;

  const side = document.createElement('div');
  side.className = 'token-side';
  wrap.appendChild(side);

  const disc = document.createElement('div');
  disc.className = 'token-disc';
  const img = document.createElement('img');
  img.src = PLAYER_IMAGE[pIdx];
  img.alt = '';
  img.onerror = () => { img.style.display = 'none'; disc.style.background = pIdx === 0 ? 'var(--blue)' : 'var(--red)'; };
  disc.appendChild(img);
  wrap.appendChild(disc);

  if (count > 1) {
    const badge = document.createElement('div');
    badge.className = 'token-count-badge';
    badge.textContent = String(count);
    wrap.appendChild(badge);
  }
  return wrap;
}

function placeToken(tokenEl, nodeId) {
  const n = NODES[nodeId];
  tokenEl.style.left = pct(n.x);
  tokenEl.style.top = pct(n.y);
}

function renderPieces() {
  const layer = document.getElementById('pieces-layer');
  layer.innerHTML = '';
  players.forEach((player, pIdx) => {
    player.groups.forEach((g) => {
      const tok = buildPieceToken(pIdx, g.count);
      placeToken(tok, g.pos);
      tok.dataset.pos = g.pos;
      tok.dataset.player = pIdx;
      layer.appendChild(tok);
    });
  });
}

const STEP_ANIM_MS = 300;

function createGhostToken(pIdx, count, atNodeId) {
  const layer = document.getElementById('pieces-layer');
  const tok = buildPieceToken(pIdx, count);
  tok.id = 'moving-token';
  placeToken(tok, atNodeId);
  layer.appendChild(tok);
  return tok;
}
function moveGhostTo(ghostEl, nodeId) {
  return new Promise((resolve) => {
    placeToken(ghostEl, nodeId);
    setTimeout(resolve, STEP_ANIM_MS);
  });
}
function removeGhostToken() {
  const ghost = document.getElementById('moving-token');
  if (ghost) ghost.remove();
}
function nextFrame() {
  return new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
}

function renderStatus() {
  el.turnIndicator.textContent = t('game.turnIndicator', { name: players[currentPlayerIdx].name });
  el.turnIndicator.className = `turn-indicator p${currentPlayerIdx}`;

  players.forEach((p, i) => {
    const card = el.playerCards[i];
    card.querySelector('.player-name').textContent = p.name;
    card.querySelector('.waiting-count').textContent = p.waiting;
    card.querySelector('.finished-count').textContent = p.finished;
    card.classList.toggle('active', i === currentPlayerIdx && !gameOver);
  });
}
function renderAll() { renderPieces(); renderStatus(); }

function setHint(text) {
  if (!text) { el.hintBar.hidden = true; el.hintBar.textContent = ''; return; }
  el.hintBar.hidden = false;
  el.hintBar.textContent = text;
}

const ANIMAL_ID = {
  do: 'animal-pig', gae: 'animal-dog', geol: 'animal-goat',
  yut: 'animal-cow', mo: 'animal-horse', baekdo: 'animal-footprint',
};

function addLog(text, cls, animalType) {
  const li = document.createElement('li');
  if (animalType && ANIMAL_ID[animalType]) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'log-animal');
    svg.setAttribute('viewBox', '0 0 64 64');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', `#${ANIMAL_ID[animalType]}`);
    svg.appendChild(use);
    li.appendChild(svg);
  }
  const span = document.createElement('span');
  span.textContent = text;
  li.appendChild(span);
  if (cls) li.className = cls;
  el.logList.appendChild(li);
  el.logList.parentElement.scrollTop = el.logList.parentElement.scrollHeight;
}

/* ---------------------------------------------------------
 * 5. Selection prompts (Promise-based UI)
 * --------------------------------------------------------- */
function clearChoiceUI() {
  document.querySelectorAll('.node.choice-option').forEach((n) => n.classList.remove('choice-option'));
  document.querySelectorAll('.piece-token.selectable').forEach((n) => n.classList.remove('selectable'));
  el.choicePanel.hidden = true;
  el.choicePanel.innerHTML = '';
}

function promptPathChoice(options) {
  return new Promise((resolve) => {
    setHint(t('hint.choosePath'));
    el.choicePanel.hidden = false;
    el.choicePanel.innerHTML = `<div class="choice-title">${t('choice.pathTitle')}</div>`;

    const finish = (choice) => { clearChoiceUI(); setHint(''); resolve(choice); };

    options.forEach((opt) => {
      const circle = document.getElementById(`node-${opt}`);
      let label = optionLabel(opt);
      if (!label) {
        const isShortcut = Object.values(DIAG_NEAR).includes(opt) || opt.startsWith('a') || opt.startsWith('b');
        label = isShortcut ? t('choice.shortcut') : t('choice.outer');
      }
      if (circle) {
        circle.classList.add('choice-option');
        circle.addEventListener('click', () => finish(opt), { once: true });
      }
      const btn = document.createElement('button');
      btn.className = 'choice-btn';
      btn.textContent = label;
      btn.addEventListener('click', () => finish(opt));
      el.choicePanel.appendChild(btn);
    });
  });
}

function promptSourceChoice(sources, playerIdx) {
  return new Promise((resolve) => {
    setHint(t('hint.choosePiece'));
    el.choicePanel.hidden = false;
    el.choicePanel.innerHTML = `<div class="choice-title">${t('choice.pieceTitle')}</div>`;

    const finish = (choice) => { clearChoiceUI(); setHint(''); resolve(choice); };

    sources.forEach((src) => {
      let label;
      if (src.type === 'home') {
        label = t('choice.newPiece');
      } else {
        const g = players[playerIdx].groups[src.idx];
        label = t('choice.groupOption', { count: g.count, pos: describePos(g.pos) });
        const matchEl = document.querySelector(`.piece-token[data-player="${playerIdx}"][data-pos="${g.pos}"]`);
        if (matchEl) {
          matchEl.classList.add('selectable');
          matchEl.addEventListener('click', () => finish(src), { once: true });
        }
      }
      const btn = document.createElement('button');
      btn.className = 'choice-btn';
      btn.textContent = label;
      btn.addEventListener('click', () => finish(src));
      el.choicePanel.appendChild(btn);
    });
  });
}

/* ---------------------------------------------------------
 * 6. Throwing the yut sticks
 * --------------------------------------------------------- */
const RESULT_TABLE = {
  0: { type: 'mo', steps: 5 },
  1: { type: 'do', steps: 1 },
  2: { type: 'gae', steps: 2 },
  3: { type: 'geol', steps: 3 },
  4: { type: 'yut', steps: 4 },
};
const SPECIAL_STICK_INDEX = 3; // only this stick carries the hidden Back-Do mark

function throwYut() {
  const sticksUp = [];
  let heads = 0;
  for (let i = 0; i < 4; i++) {
    const up = Math.random() < 0.5;
    sticksUp.push(up);
    if (up) heads++;
  }
  let result = RESULT_TABLE[heads];
  if (heads === 1 && sticksUp[SPECIAL_STICK_INDEX]) {
    result = { type: 'baekdo', steps: -1 };
  }
  return { ...result, sticksUp };
}

const STICK_TOSS_MS = 720 + 135;
const STICK_FLIP_MS = 220;

function animateSticks(sticksUp) {
  return new Promise((resolve) => {
    el.sticks.classList.add('rolling');
    const inners = el.sticks.querySelectorAll('.stick-inner');
    inners.forEach((inner) => inner.classList.remove('flipped'));
    setTimeout(() => {
      inners.forEach((inner, i) => inner.classList.toggle('flipped', !!sticksUp[i]));
      setTimeout(() => { el.sticks.classList.remove('rolling'); resolve(); }, STICK_FLIP_MS);
    }, STICK_TOSS_MS);
  });
}

function showResultBanner(result) {
  el.resultAnimalUse.setAttribute('href', `#${ANIMAL_ID[result.type]}`);
  el.resultLabel.textContent = t(`result.${result.type}.label`);
  el.resultSteps.textContent = result.steps > 0 ? t('result.moveSteps', { n: result.steps }) : t('result.moveBack');
  const bonus = result.type === 'yut' || result.type === 'mo';
  el.resultBonus.hidden = !bonus;
  el.resultBanner.hidden = false;
}
function hideResultBanner() { el.resultBanner.hidden = true; }

/* ---------------------------------------------------------
 * 7. Movement logic
 * --------------------------------------------------------- */
function getSelectableSources(playerIdx, isBackward) {
  const player = players[playerIdx];
  const list = [];
  if (!isBackward && player.waiting > 0) list.push({ type: 'home' });
  player.groups.forEach((g, idx) => list.push({ type: 'group', idx }));
  return list;
}

async function performMove(playerIdx, source, steps) {
  const player = players[playerIdx];
  let path, count;

  if (source.type === 'home') {
    count = 1;
    player.waiting -= 1;
    path = [];
  } else {
    const g = player.groups[source.idx];
    count = g.count;
    path = g.path.slice();
    player.groups.splice(source.idx, 1);
  }
  renderStatus();

  let ghost = path.length > 0 ? createGhostToken(playerIdx, count, path[path.length - 1]) : null;
  if (ghost) await nextFrame();

  if (steps < 0) {
    if (path.length >= 2) {
      path.pop();
      if (ghost) await moveGhostTo(ghost, path[path.length - 1]);
    } else {
      path = [];
    }
  } else {
    let remaining = steps;
    let firstStep = true;
    while (remaining > 0) {
      let options;
      if (path.length === 0) {
        options = ['o1']; // leaving the start: always the outer path, no choice offered
      } else {
        const cur = path[path.length - 1];
        const from = path.length >= 2 ? path[path.length - 2] : 'o0';
        const junction = isJunctionNode(cur);
        options = (junction && firstStep) ? nextOptions(cur, from) : (junction ? forcedContinue(cur, from) : nextOptions(cur, from));
      }
      if (options[0] === 'FINISH') {
        removeGhostToken();
        player.finished += count;
        addLog(t('log.finish', { name: player.name, count }), 'finish');
        renderAll();
        return { captured: false };
      }
      const chosen = options.length > 1 ? await promptPathChoice(options) : options[0];
      path.push(chosen);
      if (!ghost) { ghost = createGhostToken(playerIdx, count, chosen); await nextFrame(); }
      else { await moveGhostTo(ghost, chosen); }
      remaining--;
      firstStep = false;
    }
  }

  if (path.length === 0) {
    removeGhostToken();
    player.waiting += count;
    addLog(t('log.returnHome', { name: player.name, count }));
    renderAll();
    return { captured: false };
  }

  const finalPos = path[path.length - 1];
  let captured = false;
  const opp = players[1 - playerIdx];
  const oppIdx = opp.groups.findIndex((g) => g.pos === finalPos);
  if (oppIdx !== -1) {
    const oppGroup = opp.groups[oppIdx];
    opp.waiting += oppGroup.count;
    opp.groups.splice(oppIdx, 1);
    captured = true;
    addLog(t('log.capture', { name: player.name, opponent: opp.name, count: oppGroup.count }), 'capture');
  }

  const ownIdx = player.groups.findIndex((g) => g.pos === finalPos);
  if (ownIdx !== -1) {
    player.groups[ownIdx].count += count;
    player.groups[ownIdx].path = path;
    addLog(t('log.merge', { name: player.name, count: player.groups[ownIdx].count }));
  } else {
    player.groups.push({ pos: finalPos, path, count });
  }

  renderAll();
  removeGhostToken();
  return { captured };
}

/* ---------------------------------------------------------
 * 8. Turn flow
 * --------------------------------------------------------- */
function resultLabelText(result) {
  const extra = (result.type === 'yut' || result.type === 'mo') ? t('result.bonusLogSuffix') : '';
  const steps = result.steps > 0 ? result.steps : 1;
  return `${t(`result.${result.type}.label`)}(${steps})${extra}`;
}

async function playRoll() {
  if (busy || gameOver) return;
  busy = true;
  el.rollBtn.disabled = true;
  hideResultBanner();

  const result = throwYut();
  lastResult = result;
  await animateSticks(result.sticksUp);
  showResultBanner(result);
  addLog(`${players[currentPlayerIdx].name}: ${resultLabelText(result)}`, null, result.type);

  const isBackward = result.type === 'baekdo';
  const sources = getSelectableSources(currentPlayerIdx, isBackward);
  let captured = false;

  if (sources.length === 0) {
    addLog(t('log.deadBaekdo', { name: players[currentPlayerIdx].name }));
  } else {
    const chosenSource = sources.length === 1 ? sources[0] : await promptSourceChoice(sources, currentPlayerIdx);
    const outcome = await performMove(currentPlayerIdx, chosenSource, isBackward ? -1 : result.steps);
    captured = outcome.captured;
  }

  if (checkWin()) { busy = false; return; }

  const bonus = result.type === 'yut' || result.type === 'mo' || captured;
  if (!bonus) currentPlayerIdx = 1 - currentPlayerIdx;
  renderStatus();
  busy = false;
  el.rollBtn.disabled = false;
}

function checkWin() {
  const winnerIdx = players.findIndex((p) => p.finished === pieceTotal);
  if (winnerIdx === -1) return false;
  gameOver = true;
  lastWinnerName = players[winnerIdx].name;
  addLog(t('log.win', { name: lastWinnerName }), 'win');
  el.winMessage.textContent = t('win.title', { name: lastWinnerName });
  el.gameScreen.hidden = true;
  el.winScreen.hidden = false;
  el.rollBtn.disabled = true;
  return true;
}

/* ---------------------------------------------------------
 * 9. Screen transitions / setup
 * --------------------------------------------------------- */
let selectedPieceCount = 4;

el.pieceCountGroup.addEventListener('click', (e) => {
  const btn = e.target.closest('.option-btn');
  if (!btn) return;
  el.pieceCountGroup.querySelectorAll('.option-btn').forEach((b) => b.classList.remove('selected'));
  btn.classList.add('selected');
  selectedPieceCount = Number(btn.dataset.value);
});

function startGame() {
  pieceTotal = selectedPieceCount;
  const p1Name = el.p1NameInput.value.trim() || t('setup.player1Placeholder');
  const p2Name = el.p2NameInput.value.trim() || t('setup.player2Placeholder');
  players = [makePlayer(p1Name), makePlayer(p2Name)];
  currentPlayerIdx = 0;
  gameOver = false;
  busy = false;
  el.logList.innerHTML = '';
  hideResultBanner();
  el.sticks.classList.remove('rolling');
  el.sticks.querySelectorAll('.stick-inner').forEach((inner) => inner.classList.remove('flipped'));
  setHint('');
  el.rulesPanel.hidden = true;

  el.setupScreen.hidden = true;
  el.winScreen.hidden = true;
  el.gameScreen.hidden = false;
  el.rollBtn.disabled = false;

  buildBoardDom();
  renderAll();
  addLog(t('log.gameStart'));
}

function backToSetup() {
  el.gameScreen.hidden = true;
  el.winScreen.hidden = true;
  el.setupScreen.hidden = false;
}

el.startBtn.addEventListener('click', startGame);
el.rollBtn.addEventListener('click', playRoll);
el.restartBtn.addEventListener('click', backToSetup);
el.playAgainBtn.addEventListener('click', backToSetup);
el.rulesToggleBtn.addEventListener('click', () => { el.rulesPanel.hidden = !el.rulesPanel.hidden; });

/* ---------------------------------------------------------
 * 10. Language switching
 * --------------------------------------------------------- */
function updateLangMenuUI() {
  el.langBtnLabel.textContent = t(`lang.${getLang()}`);
  el.langMenu.querySelectorAll('.lang-option').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.lang === getLang());
  });
}

function refreshLiveText() {
  applyStaticTranslations();
  if (players.length) renderStatus();
  const startLabel = document.getElementById('start-node-label');
  if (startLabel) startLabel.textContent = t('board.startLabel');
  if (!el.resultBanner.hidden && lastResult) showResultBanner(lastResult);
  if (!el.winScreen.hidden && lastWinnerName) el.winMessage.textContent = t('win.title', { name: lastWinnerName });
}

function closeLangMenu() {
  el.langMenu.hidden = true;
  el.langBtn.setAttribute('aria-expanded', 'false');
}

el.langBtn.addEventListener('click', () => {
  const willOpen = el.langMenu.hidden;
  el.langMenu.hidden = !willOpen;
  el.langBtn.setAttribute('aria-expanded', String(willOpen));
});

el.langMenu.addEventListener('click', (e) => {
  const btn = e.target.closest('.lang-option');
  if (!btn) return;
  setLang(btn.dataset.lang);
  updateLangMenuUI();
  refreshLiveText();
  closeLangMenu();
});

document.addEventListener('click', (e) => {
  if (!el.langMenu.hidden && !document.getElementById('lang-switcher').contains(e.target)) {
    closeLangMenu();
  }
});

setLang(detectInitialLang());
updateLangMenuUI();
applyStaticTranslations();
